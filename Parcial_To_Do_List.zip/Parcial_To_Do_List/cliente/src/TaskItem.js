import React from 'react';

const TaskItem = ({ task, toggleTask, deleteTask }) => {
  return (
    <li>
      <input
        type="checkbox"
        checked={task.done}
        onChange={() => toggleTask(task._id)}
      />
      <span>{task.name}</span>
      <button onClick={() => deleteTask(task._id)}>Eliminar</button>
    </li>
  );
};

export default TaskItem;