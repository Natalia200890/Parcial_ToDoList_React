import React from 'react';

const Task = ({ task, toggleTask, deleteTask }) => {
  const handleToggleTask = () => {
    toggleTask(task._id);
  };

  const handleDeleteTask = () => {
    deleteTask(task._id);
  };

  return (
    <li className={`task-item ${task.done ? 'done' : ''}`}>
      <div className="task-buttons">
        <span onClick={handleToggleTask}>{task.name}</span>
      </div>
      <div>
        <button className="done-button" onClick={handleToggleTask}>
          Realizada
        </button>
        <button className="delete-button" onClick={handleDeleteTask}>
          Eliminar
        </button>
      </div>
    </li>
  );
};

export default Task;