import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './styles.css';

const TaskItem = ({ task, toggleTask, deleteTask }) => {
  const taskStyle = {
    textDecoration: task.done ? 'line-through' : 'none', 
  };

  const buttonStyle = {
    fontSize: '12px', 
  };

  return (
    <div className="task-box">
      <span className="task-text" style={taskStyle}>
        {task.name}
      </span>
      <div className="task-buttons">
        <button className="complete-button" style={buttonStyle} onClick={() => toggleTask(task._id)}>
          Completada
        </button>
        <button className="delete-button" onClick={() => deleteTask(task._id)}>
          Eliminar
        </button>
      </div>
    </div>
  );
};

const App = () => {
  const [taskItems, setTaskItems] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [completedTasks, setCompletedTasks] = useState(0);
  const [pendingTasks, setPendingTasks] = useState(0);

  useEffect(() => {
    fetchTasks();
  }, []);

  useEffect(() => {
    const completed = taskItems.filter(task => task.done).length;
    setCompletedTasks(completed);
    setPendingTasks(taskItems.length - completed);
  }, [taskItems]);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/tasks');
      setTaskItems(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const addTask = async () => {
    if (newTask.trim() !== '') {
      try {
        const response = await axios.post('http://localhost:5000/tasks', {
          name: newTask,
        });
        setTaskItems([...taskItems, response.data]);
        setNewTask('');
      } catch (error) {
        console.error('Error adding task:', error);
      }
    }
  };

  const toggleTask = async (id) => {
    const updatedTasks = [...taskItems];
    const taskToUpdate = updatedTasks.find(task => task._id === id);
    taskToUpdate.done = !taskToUpdate.done;

    try {
      await axios.put(`http://localhost:5000/tasks/${id}`, taskToUpdate);
      setTaskItems(updatedTasks);
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/tasks/${id}`);
      const updatedTasks = taskItems.filter(task => task._id !== id);
      setTaskItems(updatedTasks);
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const deleteAllTasks = async () => {
    try {
      await axios.delete('http://localhost:5000/tasks');
      setTaskItems([]);
    } catch (error) {
      console.error('Error deleting all tasks:', error);
    }
  };

   return (
    <div className="App">
      <header>
        <h1>Lista de Tareas...</h1>
      </header>
      <main>
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Escriba su tarea aqui"
          className="input-task"
        />
        <button onClick={addTask} className="add-button btn btn-primary">
          Agregar
        </button>
        <div>
  <p className="task-status">Tareas completadas: {completedTasks}</p>
  <p className="task-status">Tareas pendientes: {pendingTasks}</p>
</div>
       
        <div className="task-list">
          {taskItems.map(task => (
            <TaskItem
              key={task._id}
              task={task}
              toggleTask={toggleTask}
              deleteTask={deleteTask}
            />
          ))}
        </div>
        {taskItems.length > 0 && (
          <button onClick={deleteAllTasks} className="delete-all-button btn btn-danger">
            Eliminar todas
          </button>
        )}
      </main>
    </div>
  );
};

export default App;
