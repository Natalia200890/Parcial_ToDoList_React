import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Task from './Task';

const TaskList = () => {
  const [taskItems, setTaskItems] = useState([]);
  const [newTask, setNewTask] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/tasks');
      setTaskItems(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const addTask = async () => {
    if (newTask.trim() !== '') {
      try {
        const response = await axios.post('http://localhost:5000/tasks', {
          name: newTask,
        });
        setTaskItems([...taskItems, response.data]);
        setNewTask('');
      } catch (error) {
        console.error('Error adding task:', error);
      }
    }
  };

  const toggleTask = async (id) => {
    const updatedTasks = [...taskItems];
    const taskToUpdate = updatedTasks.find((task) => task._id === id);
    if (taskToUpdate) {
      taskToUpdate.done = !taskToUpdate.done;
      setTaskItems(updatedTasks);
    }
  };

  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/tasks/${id}`);
      const updatedTasks = taskItems.filter((task) => task._id !== id);
      setTaskItems(updatedTasks);
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  return (
    <div className="task-container">
      <input
        type="text"
        className="task-input"
        placeholder="Nueva tarea..."
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
      />
      <button className="add-button" onClick={addTask}>
        Agregar Tarea
      </button>
      <ul className="task-list">
        {taskItems.map((task) => (
          <Task
            key={task._id}
            task={task}
            toggleTask={toggleTask}
            deleteTask={deleteTask}
          />
        ))}
      </ul>
    </div>
  );
};

export default TaskList;